/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Magic.Design;

import java.awt.Color;

/**
 *
 * @author satwik
 */
public class MyJButton extends javax.swing.JButton {
    public MyJButton() {
        designMyButton();
    }
    
    private void designMyButton() {

        this.setForeground(new Color(0,0,0));

    }
    
}
