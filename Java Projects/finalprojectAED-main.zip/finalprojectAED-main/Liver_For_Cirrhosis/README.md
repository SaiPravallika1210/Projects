# AED_FINAL_PROJECT

The title of our project is 
Liver for cirrhosis

the group members are

Lissa Rodrigues
002769776

Satwik Kumar
002700710

Cheril Yogi
002790646

AIM OF THE PROJECT

cirrhosis is one of the most lethal Disease in USA, 25 percent of cancer cases every year constitutes to LIVER and for every 9 minutes a person dies of liver failures .
cirrhosis also called liver Cancer,  affects the activity of liver and thereby affecting the growth of white Blood cells in our body.
People are unaware this disease and its possible cure!


PROPOSED SOLUTION
Creating a platform where a potential Donor will register and a potential patient will register as a patient

Building a trust among users by having validation checkpoints

Based on the availability of bone marrow, eligibility of donor, consent from patient, a possible treatment was done by a doctor
![image](https://user-images.githubusercontent.com/113062056/206950463-2e0c5148-14d2-457b-a182-7f27fe43e450.png)

Salient Features image


Easy to understand for new Users

Raising awareness about possible solution of lethal disease.

Application is connecting users from all around the world and connecting each other from user level to enterprise level using multiple networks in  Eco System model

User at each level can check status their work request

System Employee can communicate with his user through Email


WORK FLOW DIAGRAM DONAR
![image](https://user-images.githubusercontent.com/113062056/206950648-9af42554-2c23-427e-8387-c41ad0618e92.png)

WORK FLOW DIAGRAM FOR PATIENT
![image](https://user-images.githubusercontent.com/113062056/206950833-5ba1d783-cae7-41af-8058-c993268006fd.png)

Class Diagram
![UML-Class-Diagram (2)](https://user-images.githubusercontent.com/113062056/206951379-c2aeda1a-7046-463c-9d52-d9b71fb81642.png)



