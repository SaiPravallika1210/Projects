/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Magic.Design;

/**
 *
 * @author pravallika
 */
public class MyJTextField extends javax.swing.JTextField {
    public MyJTextField() {
//        this.setFont(new java.awt.Font("Arial", 1, 14));
    }
    
}
